package com.aspire.user.config;

public class JwtAuthentication {

}
